#include "header.h"

int main()
{
    struct sockaddr_in serverAddress;
    struct sockaddr_in fromAddress;
    
    char smessage[BUFFER_SIZE];
    char rmessage[BUFFER_SIZE];
    int addr_size;
    int sentBytes;
    int readBytes;
    memset(&serverAddress, 0, sizeof(serverAddress));
    
    serverAddress.sin_family = AF_INET;
    inet_aton("127.0.0.1", (struct in_addr*) &serverAddress.sin_addr.s_addr);
    serverAddress.sin_port = htons(20162);
    
    int client_socket = socket(AF_INET, SOCK_DGRAM, 0);
    
    if(client_socket == -1)
        printf("socket error\n");
    
    
    while(1)
    {
        memset(smessage, 0,BUFFER_SIZE);
        memset(rmessage,0,BUFFER_SIZE);
        
        printf("%s","please write a message(QT to QUIT) : ");
        scanf("%s",smessage);
        
        sendto(client_socket, smessage, strlen(smessage), 0, (struct sockaddr*)&serverAddress, sizeof(serverAddress));
        addr_size = sizeof(fromAddress);
        
        if(smessage[0] == 'Q' && smessage[1] == 'T') break;
        
        
        readBytes = recvfrom(client_socket, rmessage, BUFFER_SIZE,0, (struct sockaddr*) &fromAddress, (socklen_t*)&addr_size);

        printf("%s", " A message from server : ");
        printf("%s \n",rmessage);
    }
    close(client_socket);
    return 0;
}
