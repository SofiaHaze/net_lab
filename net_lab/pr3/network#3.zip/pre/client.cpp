//client.cpp
# include "header.h"


int main(){
    struct sockaddr_in serverAddress;
    memset(&serverAddress, 0, sizeof(serverAddress));
    serverAddress.sin_family = AF_INET;
    inet_aton("127.0.0.1", (struct in_addr*) &serverAddress.sin_addr.s_addr);
    serverAddress.sin_port = htons(PORT);
    
    // 소켓을 생성하시오.
    int connectFD = socket(AF_INET, SOCK_DGRAM,0); // SOCK_STREAM: TCP, SOCK_DGRAM: UDP
    
    
    
    int input;
    char line[200];
    
    int readBytes, sentBytes;
    char sendBuffer[BUFFER_SIZE];
    char receiveBuffer[BUFFER_SIZE];
    
    while(true){
        
        memset(sendBuffer, 0, sizeof(BUFFER_SIZE));
        memset(receiveBuffer, 0, sizeof(BUFFER_SIZE));
        
        printf("(press q to exit) Input:");
        
        input = scanf("%s", line);
        if (input < 0) {
            printf("Inpur error\n"); fflush(stdout);
            break;
        }
        else if(line[0]=='q'){
            printf("wait.. to exit \n");
            break;
        }
        
        sentBytes = sprintf(sendBuffer, "%s", line);
        
        sentBytes = sendto(connectFD, sendBuffer, BUFFER_SIZE, 0, (struct sockaddr*) &serverAddress, sizeof(serverAddress));
        if (sentBytes <= 0) {
            printf("Write error\n");
            fflush(stdout);
            break;
        }
        printf("Successfully ur message is sent to server");
        socklen_t serverAddressLength=sizeof(serverAddress);
        readBytes = recvfrom(connectFD,receiveBuffer, BUFFER_SIZE, 0, (struct sockaddr*) &serverAddress, &serverAddressLength);
  
        if (readBytes <= 0) {
            printf("Read error\n");
            
            fflush(stdout);
            break; }
        
        printf("Result: %s\n",receiveBuffer);
        fflush(stdout);
        
       
    }
    
    // 소켓을 close 하시오.
    close(connectFD);
    return 0; }