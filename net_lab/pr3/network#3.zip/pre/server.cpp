//server.cpp
# include "header.h"
int main(){
    struct sockaddr_in serverAddress, clientAddress;
    socklen_t clientAddressLength =0;
    memset(&serverAddress, 0, sizeof(serverAddress));
    memset(&clientAddress, 0, sizeof(clientAddress));
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = htonl(INADDR_ANY);
    serverAddress.sin_port = htons(PORT);
    
    // 서버 소켓을 생성하고 서버 주소와 bind 하시오.
    int connectFD = socket(AF_INET, SOCK_DGRAM,0); // SOCK_STREAM: TCP, SOCK_DGRAM: UDP
    bind(connectFD, (struct sockaddr *) &clientAddress, sizeof(clientAddress));
    
    int readBytes, sentBytes;
    char sendBuffer[BUFFER_SIZE];
    char receiveBuffer[BUFFER_SIZE];
    
    printf("running \n");
    while(true){
        //채팅 프로그램을 완성하시오.
        memset(sendBuffer, 0, sizeof(BUFFER_SIZE));
        memset(receiveBuffer, 0, sizeof(BUFFER_SIZE));
        
        socklen_t serverAddressLength=sizeof(serverAddress);
        readBytes = recvfrom(connectFD,receiveBuffer, BUFFER_SIZE, 0, (struct sockaddr*) &serverAddress, &serverAddressLength);
        
        printf("I got messages\n");
        
        sprintf(sendBuffer,"%s",receiveBuffer);
        sentBytes = sendto(connectF    // 서버 소켓을 close 하시오.D, sendBuffer, BUFFER_SIZE, 0, (struct sockaddr*) &clientAddress, sizeof(clientAddress));
        
    }
    close(connectFD);
    return 0; }