#include "header.h"

int main()
{
    struct sockaddr_in serverAddress, clientAddress;
    socklen_t clientAddressLength =0;
    
    
    char smessage[BUFFER_SIZE];
    char rmessage[BUFFER_SIZE];
    int receivedBytes, addr_size;
    
    
    memset(&serverAddress, 0, sizeof(serverAddress));
    memset(&clientAddress, 0, sizeof(clientAddress));
    
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = htonl(INADDR_ANY);
    serverAddress.sin_port = htons(20162);
    
    int server_socket = socket(AF_INET, SOCK_DGRAM, 0);
    
    if(server_socket ==-1)
    {
        printf("socket() error");
    }
    if(bind(server_socket, (struct sockaddr*) &serverAddress, sizeof(serverAddress)) == -1)
    {
        printf("bind error");
    }
    printf("Server is running!\n");
    
    while(1)
    {
        memset(rmessage,0,BUFFER_SIZE);
        clientAddressLength=sizeof(clientAddress);
        
        receivedBytes=recvfrom(server_socket,rmessage, BUFFER_SIZE,0,(struct sockaddr*) &clientAddress, &clientAddressLength);
        
        if(rmessage[0]=='Q' && rmessage[1]=='T')
            break;
        sendto(server_socket, rmessage, strlen(rmessage),0,(struct sockaddr*)&clientAddress, sizeof(clientAddress));
        printf("%s", "Message from client : ");
        printf("%s\n",rmessage);
        
        printf("%s\n", "Please write a message(QT to QUIT):");
        scanf("%s",smessage);
        
        sendto(server_socket, smessage, strlen(smessage),0,(struct sockaddr*)&clientAddress, sizeof(clientAddress));
        if(smessage[0] =='Q' && smessage[1] =='T')
            break;
        memset(smessage, 0, BUFFER_SIZE);
    }
    
    close(server_socket);
    return 0;
}
