#ifndef Net03_header_h
#define Net03_header_h

# include <stdio.h>
# include <string.h>
# include <netinet/in.h> 
# include <sys/socket.h>
# include <arpa/inet.h>
# include <unistd.h>
# include <stdlib.h>

# define PORT 20166
# define BUFFER_SIZE 4096

#endif

